package com.example.macstudent.player;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class PlayerActivity extends AppCompatActivity implements View.OnClickListener{
Button btnAud,btnVid;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);

        btnAud = findViewById(R.id.btnAud);
        btnAud.setOnClickListener(this);

        btnVid = findViewById(R.id.btnVid);
        btnVid.setOnClickListener(this);


    }

    @Override
    public void onClick(View view) {
            if(view.getId() == btnAud.getId()){
                Intent audioIntent = new Intent(this,AudioActivity.class);
                startActivity(audioIntent);
            }
        if(view.getId() == btnVid.getId()){
            Intent videoIntent = new Intent(this,VideoActivity.class);
            startActivity(videoIntent);
        }
    }
}
