package com.example.macstudent.player;

import android.media.MediaPlayer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.concurrent.TimeUnit;

public class AudioActivity extends AppCompatActivity implements View.OnClickListener {

    ImageButton btnPlay,btnPause,btnForward,btnRewind;
    SeekBar seekbar;
    TextView txtTime;
    MediaPlayer mediaPlayer;
    private int startTime = 0;
    private int finishTime = 0;
    private Handler myHandler = new Handler();
    private int seekTime = 5000;

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        mediaPlayer.stop();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio);

        seekbar = (SeekBar)findViewById(R.id.seekBar);
        btnPlay = findViewById(R.id.imagePlay);
        btnPause = findViewById(R.id.imagePause);
        btnForward = findViewById(R.id.imageff);
        btnRewind = findViewById(R.id.imagerew);
        txtTime = (TextView)findViewById(R.id.textView);



        mediaPlayer = MediaPlayer.create(getApplicationContext(),
                R.raw.dichotomy);
        finishTime = mediaPlayer.getDuration();
        startTime = mediaPlayer.getCurrentPosition();
        seekbar.setMax((int) finishTime);

        mediaPlayer = MediaPlayer.create(getApplicationContext(),
                R.raw.dichotomy);
        finishTime = mediaPlayer.getDuration();
        startTime = mediaPlayer.getCurrentPosition();
        seekbar.setMax((int) finishTime);


        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer.start();
                seekbar.setProgress((int)startTime);
                myHandler.postDelayed(UpdateSongTime,100);
            }
        });

        btnPause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer.pause();
            }
        });

        btnForward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int currentPosition = mediaPlayer.getCurrentPosition();
                if(currentPosition + seekTime <= mediaPlayer.getDuration()){
                    mediaPlayer.seekTo(currentPosition + seekTime);
                }else{
                    mediaPlayer.seekTo(mediaPlayer.getDuration());
                }
            }
        });

        btnRewind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int currentPosition = mediaPlayer.getCurrentPosition();
                if(currentPosition - seekTime >= 0){
                    mediaPlayer.seekTo(currentPosition - seekTime);
                }else{
                    mediaPlayer.seekTo(0);
                }
            }
        });

    }

    private Runnable UpdateSongTime = new Runnable() {
        public void run() {
            startTime = mediaPlayer.getCurrentPosition();
            txtTime.setText(String.format("%d min, %d sec",
                    TimeUnit.MILLISECONDS.toMinutes((long) startTime),
                    TimeUnit.MILLISECONDS.toSeconds((long) startTime) -
                            TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.
                                    toMinutes((long) startTime)))
            );
            seekbar.setProgress((int)startTime);
            myHandler.postDelayed(this, 100);
        }
    };
    @Override
    public void onClick(View view) {

    }
}
