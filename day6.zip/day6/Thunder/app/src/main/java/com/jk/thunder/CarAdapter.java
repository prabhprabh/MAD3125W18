package com.jk.thunder;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by jkp on 2018-04-09.
 */

public class CarAdapter extends BaseAdapter {
    Context context;
    int logos[];
    String[] companyNames;
    LayoutInflater inflater;

    CarAdapter(Context context,int logos[], String[] companyNames){
        this.context = context;
        this.logos = logos;
        this.companyNames = companyNames;
        inflater = (LayoutInflater.from(context));
    }

    @Override
    public int getCount() {
        return companyNames.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {

        view = inflater.inflate(
                R.layout.carcompany_spinner_item,
                null);

        ImageView carLogo = (ImageView) view.findViewById(
                R.id.imgLogo);
        TextView companyName = (TextView) view.findViewById(
                R.id.txtCompany);

        carLogo.setImageResource(logos[position]);
        companyName.setText(companyNames[position]);

        return view;

    }
}
