package com.jk.thunder;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class SupportActivity extends AppCompatActivity implements View.OnClickListener{
Button btnCall,btnSms,btnEmail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_support);

    btnCall = (Button)findViewById(R.id.btnCall);
    btnCall.setOnClickListener(this);

        btnSms = (Button)findViewById(R.id.btnSms);
        btnSms.setOnClickListener(this);

        btnEmail = (Button)findViewById(R.id.btnEmail);
        btnEmail.setOnClickListener(this);
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btnCall:
                makeCall();
                break;
            case R.id.btnEmail:
                sendEmail();
                break;
            case R.id.btnSms:
                sendSMS();
                break;
        }
     }
    private void makeCall() {
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:4379227146"));

        if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(getApplicationContext(), "Call Permission denied", Toast.LENGTH_LONG).show();
            return;
        }
        startActivity(callIntent);
    }

    public void sendEmail(){
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setType("text/plain");
        emailIntent.putExtra(Intent.EXTRA_EMAIL,new String[]{"prabh@gmail.com"});

        emailIntent.putExtra(Intent.EXTRA_SUBJECT,"test email");

        emailIntent.putExtra(Intent.EXTRA_TEXT,"this is a text message");

        emailIntent.setType("message/rfc822");


        startActivity(Intent.createChooser(emailIntent,"select Email Client"));

    }

    public void sendSMS(){
        Intent smsIntent = new Intent(Intent.ACTION_SENDTO,Uri.parse("smsto:4379227146"));
        smsIntent.putExtra("sms_body","test message");

        if (ActivityCompat.checkSelfPermission((getApplicationContext()), Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {

            Toast.makeText(getApplicationContext(), "SMS Permission denied", Toast.LENGTH_LONG).show();
            return;
        }
        startActivity(smsIntent);
    }


}
