package com.example.macstudent.melodyfinal;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by macstudent on 2018-04-23.
 */

public class ImageAdapter extends BaseAdapter {

    Context context;
    String[] values;
    int[] images;
    View view;
    LayoutInflater layoutInflater;


    public ImageAdapter(Context context, String[] values, int[] images) {
        this.context = context;
        this.values = values;
        this.images = images;
    }

    @Override
    public int getCount() {
        return values.length;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (convertView == null) {
            view = new View(context);
            view = layoutInflater.inflate(R.layout.image_grid_view, null);
            ImageView imageView = (ImageView) view.findViewById(R.id.imageView);
            TextView textview = (TextView) view.findViewById(R.id.textview);
            imageView.setImageResource(images[position]);
            textview.setText(values[position]);
        }
        return view;
    }

}
