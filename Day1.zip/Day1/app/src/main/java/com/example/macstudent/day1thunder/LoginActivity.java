package com.example.macstudent.day1thunder;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;


public class LoginActivity extends AppCompatActivity implements View.OnClickListener{

    Button btnLogin; //creating object
    Button btnRegister;
    EditText edtUsername;
    EditText edtPassword;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        btnLogin = (Button) findViewById(R.id.btnLogin);   //linking object to button
        btnLogin.setOnClickListener(this);

        btnRegister = (Button) findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(this);

        edtUsername = (EditText) findViewById(R.id.edtUsername);
        edtPassword = (EditText) findViewById(R.id.edtPassword);
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == btnLogin.getId()){  //givers component which has been clicked
            String uname = edtUsername.getText().toString();
            String pass =edtPassword.getText().toString();

            

            Toast.makeText( this,uname  +"" +  pass,Toast.LENGTH_LONG).show();


        }
        else if(view.getId() == btnRegister.getId()){
            Toast.makeText(this,"Register Clicked",Toast.LENGTH_LONG).show();

        }
    }

}
